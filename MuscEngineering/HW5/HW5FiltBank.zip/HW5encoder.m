% Spencer Chan
% Music and Engineering
% MPEG Encoder HW 5

clc; clear all; close all;
enc = Encoding();

[orig, enc2] = MPEGencode('guitarriff.wav',enc);

%%

[output] = MPEGdecode(s);

%%
% soundsc(orig,fs)
soundsc(output,enc2.fs)
figure
plot(output)

%%
soundsc(orig,enc2.fs)