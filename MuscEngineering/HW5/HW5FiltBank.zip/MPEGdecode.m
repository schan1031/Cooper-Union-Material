function [ SubAcc ] = MPEGdecode( obj )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

load('filtdecodecoeff.mat');
ind = 0;
V = zeros(1024,1);
V2 = zeros(32,1);
U = zeros(512,1);
Sout = V2;
SubAcc = [];

Enc = [];
for i = 1:length(obj.frames)
    
    z = obj.frames{1,i};
    Enc = [Enc; z];
end


%%

for ind = 1:length(Enc)
    
    S = Enc(ind,:);
    
    tmpV = zeros(64,1);
    
    for ii = 1:64
        for kk = 1:32
            V2(kk) = cos((16+ii)*(2*kk+1)*pi/64).*S(kk);
        end
        tmpV(ii) = sum(V2);
    end
    
    V = [tmpV; V(1:end-64)];
    
%     if ind>1
%         error('s')
%     end

%     S = Enc(ind+1:ind+32);
%     1
%     for ii = 65:1024
%         V(ii) = Enc(ind+ii-64);
%     end
%     
%     for ii = 1:64
%         for kk = 1:32
%             V2(kk) = cos((16+ii)*(2*kk+1)*pi/64).*S(kk);
%         end
%         V(ii) = sum(V2);
%     end
%     Vswap = [V(65:1024); V(1:64)];
%     V = Vswap;
    
    
%     Build Value Vector U
    for ii = 1:8
        for jj = 1:32
            U((ii-1)*64+jj) = V((ii-1)*128+jj);
            U((ii-1)*64+32+jj) = V((ii-1)*128+96+jj);
        end
    end
    
    % Window
    W = U.*D;
    
    % 32 Samples
    
    for jj = 1:32
        for ii = 1:16
            W2 = zeros(16,1);
            W2(ii) = W(jj+32*(ii-1));
        end
        Sout(jj) = sum(W2);
    end
    
    SubAcc = [SubAcc; Sout];
    
    h=waitbar(0);
    waitbar(ind/length(Enc),h,num2str(ind/length(Enc)*100));
    
end
close(h)


end

