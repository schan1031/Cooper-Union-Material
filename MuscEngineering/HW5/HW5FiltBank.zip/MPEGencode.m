function [soundin, obj ] = MPEGencode( filename, obj )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

load('filtercoeff.mat');
% stem(C)

[soundin, fs] = audioread(filename);
soundin = soundin(:,1);
obj.fs = fs;

% Preallocate
x = zeros(512,1);
ind = 1;
Sub = zeros(64,1);
Subsum = zeros(12,32);
SubAcc = [];

%%

loop = 1;
while ind < length(soundin)-1024
    
    for frame = 1:12
        
        % Read in 32 at a time
        
%         for ii = 33:512
%             x(ii) = soundin(ind+ii-32);
%         end
%         
%         for ii = 1:32
%             x(ii) = soundin(ind+513);
%         end

        x(33:end) = x(1:end-32);
        x(1:32) = soundin(ind:ind+31);

        
        % Window
        Z = x.*C;
        
        Y = zeros(8,1);
        Ysum = zeros(64,1);
        
        % Partial Calculation
        v = [0 1 2 3 4 5 6 7];
        for ii = 1:64
            for jj = 1:length(v)
                Y(jj) = Z(ii+64*v(jj));
            end
            Ysum(ii) = sum(Y);
        end
        
        % 32 Samples Matrixing
        for ii = 1:32
            Sub2 = [];
            for jj = 1:64
                Sub(jj) = cos((2*ii+1)*(jj-16)*pi/64).*Ysum(jj);
%                 Sub2 = [Sub2; Sub(jj)];
            end
            Subsum(frame,ii) = sum(Sub);
        end
        
        ind = ind+32;
    end
    
    obj.frames{loop} = Subsum;
    loop = loop + 1;
    
%     SubAcc = [SubAcc; Subsum];
    
%     ind = ind + 32;
    h = waitbar(ind/length(soundin));
    waitbar(ind/length(soundin),h,num2str(ind/length(soundin)*100));
end
close(h)


end

