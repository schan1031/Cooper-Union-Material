classdef Encoding
    %UNTITLED8 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        fs
        frames
    end
    
    methods

    end
    
end

