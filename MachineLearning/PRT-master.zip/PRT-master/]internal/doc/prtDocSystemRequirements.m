%% Pattern Recognition Toolbox System Requirements
% Pattern Recognition Toolbox requires MATLAB(R)
%
% Copyright 2011 New Folder Consulting L.L.C.