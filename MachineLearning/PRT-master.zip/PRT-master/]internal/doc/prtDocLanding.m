%% Pattern Recognition Toolbox
%
% Bellow are some links to get you started exploring the PRT.
% The PRT is about 8 years old now but it is always evolving. Be sure to
% stay up to date with new releases by checking us out at
% <https://github.com/newfolder/PRT GitHub>.
%
% * <prtDocGettingStarted.html Getting Started>
% * <prtDocUsersGuide.html User's Guide>
% * <prtDocReleaseNotes.html Release Notes>
% * <prtDocFunctionList.html A Categorized List of Popular Functions>
%
% Copyright 2013 New Folder Consulting L.L.C.