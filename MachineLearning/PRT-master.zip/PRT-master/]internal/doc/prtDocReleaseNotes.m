%% Pattern Recognition Toolbox Release Notes
% 
%
%% Version 4.0 - 19-Feb-2013
% <https://github.com/newfolder/PRT>.
%
%
% Copyright 2013 New Folder Consulting L.L.C.