Obtained from http://www.biostat.jhsph.edu/~ririzarr/Teaching/649/

04.23.2008