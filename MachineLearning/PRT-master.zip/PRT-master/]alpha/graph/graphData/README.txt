All of these files were found on-line, circa October 2012.  Please see the accompanying text files to properly attribute these data sets if you use them in your work.

Also see:

http://www-personal.umich.edu/~mejn/netdata/
http://vlado.fmf.uni-lj.si/pub/networks/data/UciNet/UciData.htm

for significant additional data sets.