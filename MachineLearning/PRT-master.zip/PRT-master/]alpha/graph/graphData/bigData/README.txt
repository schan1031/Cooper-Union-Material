This folder is for the larger graph data sets that by default are not included in the PRT.  They are available as .MAT files here:

http://www.duke.edu/~pat7/prtGraphData/
